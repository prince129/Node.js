// TODO: create a basic server with express
// that will send back the index.html file on a GET request to '/'
// it should then send back jsonData on a GET to /data
var express = require('express');

var jsonData = {count: 12, message: 'hey'};

var app = express();

app.get('/', (req, res) => {
   res.sendFile(__dirname + '/index.html', function(err){
       if(err){
           res.send(err);
       }
   });
});

app.get('/data', (req, res) =>{
    res.json(jsonData);
});

var port = 8080;
const hostname = '127.0.0.1';
app.listen(port, hostname, ()=>{
    console.log(`Server running at http://${hostname}:${port}/`);
});