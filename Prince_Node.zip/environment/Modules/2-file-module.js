var callback = require('./callback');

var handleResults = function(err, results, time){
    if(err){
        console.log("ERROR :"+err.message);
    } else{
        console.log("The results are: "+ results + " { "+ time + "ms }");
    }
};

for(var i=0; i<10; i++){
console.log("calling evendoubler with parameter" + i );
callback.evenDoubler(i, handleResults);
}
console.log("-------");

console.log("The foo variable from module callback == "+callback.foo);

console.log("The max time variable is not exported "+callback.maxTime);